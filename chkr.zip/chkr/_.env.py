TELEGRAM_BOT_TOKEN=8363486220:AAF7zDmmz-BQutPirhwpcjErlWNhEuzrZJI
MONGODB_URI=mongodb+srv://ElectraOp:BGMI272@cluster0.1jmwb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
